

mature_mir_gene_node_Info
gene_node_Info    (only contains protein coding genes)


mature_mir_transcript_node_Info
transcript_node_Info   (only contains protein coding transcripts)